
/*	File Name: Repository.java
 * 	File Author: Robert O'Brien
 * 	Student Number: C20436696
 * 	Publish Date: 17/02/2022
 */
public class Repository {
	int num;
	boolean printed = true;
	
	public int getNum() {
		return this.num;
	}
	
	public void setNum(int num) {
		this.num = num;
	}
	
	public boolean isPrinted() {
		return this.printed;
	}
	
	public void setPrinted(boolean printed) {
		this.printed = printed;
	}
}
