
/*	File Name: Driver.java
 * 	File Author: Robert O'Brien
 * 	Student Number: C20436696
 * 	Publish Date: 17/02/2022
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Library {
	ArrayList<Book> bookCollection = new ArrayList<Book>();
	Book b;
	public static void main(String[] args) {
		Library driver = new Library();
		Book b;
		//Creating a New Book
		b = new Book("James", "Joyce", "Ab11228", 1900);
		//Adding Book to the Collection
		driver.bookCollection.add(b);
		//Creating and Starting the Member Threads
		Member m1 = new Member(driver);
		Member m2 = new Member(driver);
		m1.start();
		m2.start();
	}

	public int findBookIndex(String ISBN) {
		//Searching all books in Collection, if ISBN matches any - return the Index.
		//if not return -1.
		for (Book aBook : bookCollection) {
			if (ISBN.equalsIgnoreCase(aBook.getIsbn())) {
				return bookCollection.indexOf(aBook);
			}
		}
		return -1;
	}

	public Book loanBook(int ind) {
		//Checking the Index given is possible for the given Collection size. If so, loan the book
		if (bookCollection.size() > ind) {
			Book temp;
			temp = bookCollection.get(ind);
			System.out.println("Book has been Loaned!");
			bookCollection.remove(ind);
			b = temp;
		}
		return b;
	}

	public Book returnBook(Book b) {
		//Add book back to Collection 
		bookCollection.add(b);
		return b;
	}


}// end Library
class Member extends Thread{
	Library l;
	Book b;
	String isbn1 = "Ab11228";
	int index;
	public Member(Library l) {
		this.l = l;
	}

	public void run() {
		System.out.println("Thread is running...");
		//Giving the ISBN to search for
		index = this.l.findBookIndex("Ab11228");
		System.out.println(index);
		if (index >= 0) {
			b = this.l.loanBook(index); //Loaning the Book, if possible
			try {
				Thread.sleep(2000); //Sleeping for 2000ms
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			this.l.returnBook(b); //Then, returning the book 
		}else {
			System.out.println("Book not Found!");//If not possible, notifying the customer
		}
	}
}// end Member

