/*	File Name: Counter.java
 * 	File Author: Robert O'Brien
 * 	Student Number: C20436696
 * 	Publish Date: 17/02/2022
 */
public class Counter extends Thread{
	public static void main(String[] args) {
		//Creation of Threads 
		Repository r = new Repository();
		Counter c = new Counter(r);
		Publisher p = new Publisher(r);
		new Thread(c).start(); //Starting Threads
		p.start();
	}

	private Repository r;
	static Publisher p;
	public Counter(Repository r) {
		this.r = r;
	}

	public void run() {
		synchronized(r) {
			System.out.println("Thread is Running...");
			//Looping through, creating numbers
			for(int i = 0; i < 100; i++) {
				//Waiting for Flag to be changed to contuinue, waiting until then
				while(!r.isPrinted()) {
					try {
						r.wait();
					} catch (Exception e) {}
				}
				//Once changed, create new number, change flag back and notify other thread
				r.setNum(i);
				r.setPrinted(false);
				r.notify();
			}}
	}


}

class Publisher extends Thread {
	private Repository r;
	public Publisher(Repository r) {
		this.r = r;
	}

	public void run() {
		synchronized(r){
			//Looping through printing numbers created
			for(int i = 0; i < 100; i++) {
				//Waiting for flag to be changed to continue, waiting until then
				while(r.isPrinted()) {
					try {
						r.wait();
					} catch (InterruptedException e) {}
				}
			}
			//Once changed, printing the number, change flag back then notify the other thread
			System.out.println(r.getNum());
			r.setPrinted(true);
			r.notify();	
		}

	}

}

